<?php
    function loadClass($c){
      include ROOT."/class/".$c.".class.php";
    }
 ?>
