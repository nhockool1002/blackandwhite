<?php
  $configDB = array();
  $configDB["host"]         =       "localhost";
  $configDB["database"]     =       "blackandwhite";
  $configDB["user"]         =       "root";
  $config["pass"]           =       "";

  define("HOST", "localhost");
  define("DB_NAME", "blackandwhite");
  define("DB_USER", "root");
  define("DB_PASS", "");
  define("ROOT", "D:/Dev/Software/xampp/htdocs/blackandwhite");
  define("BASE_URL", "http://".$_SERVER['SERVER_NAME']);

  $sitename = "BlackAndWhite.ORG";
  $slogan = "Thư viện danh cho sinh viên khiếm thị";
?>
