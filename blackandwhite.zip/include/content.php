<div class="col-sm-10">
    <nav class="navbar navbar-default navbar-fnt navbar-backgrnd menu-primary showcase">
    <center><div class="nav-link active" href="#"><span>Sách</span></div></center>
  </nav>
  <div class="row showcases">
    <div class="col-sm-12 text-sm-center">
      <div class="card-deck-wrapper">
        <div class="card-deck">
          <div class="col-sm-3">
            <div class="card bookoject">
              <img class="card-img-top" src="book/1.jpg" alt="Card image cap">
              <div class="card-block">
                <h4 class="card-title">Đối thoại với nhà báo</h4>
                <p class="card-text"><small class="text-muted">Tác giá : Duy Khanh</small></p>
              </div>
            </div>
          </div>
          <div class="col-sm-3">
          <div class="card bookoject">
            <img class="card-img-top" src="book/2.jpg" alt="Card image cap">
            <div class="card-block">
              <h4 class="card-title">Đừng hoang tưởng về biển lớn</h4>
              <p class="card-text"><small class="text-muted">Tác giá : Alan Phan</small></p>
            </div>
          </div>
          </div>
          <div class="col-sm-3">
          <div class="card bookoject">
            <img class="card-img-top" src="book/3.jpg" alt="Card image cap">
            <div class="card-block">
              <h4 class="card-title">7 thói quen bạn trẻ thanh đạt</h4>
              <p class="card-text"><small class="text-muted">Tác giá : Sean Covey</small></p>
            </div>
          </div>
          </div>
          <div class="col-sm-3">
          <div class="card bookoject">
            <img class="card-img-top" src="book/4.jpg" alt="Card image cap">
            <div class="card-block">
              <h4 class="card-title">Chat với tình địch</h4>
              <p class="card-text"><small class="text-muted">Tác giá : Cấn Vân Khánh</small></p>
            </div>
          </div>
          </div>
          <div class="col-sm-3">
          <div class="card bookoject">
            <img class="card-img-top" src="book/1.jpg" alt="Card image cap">
            <div class="card-block">
              <h4 class="card-title">Đối thoại với nhà báo</h4>
              <p class="card-text"><small class="text-muted">Tác giá : Duy Khanh</small></p>
            </div>
          </div>
          </div>
          <div class="col-sm-3">
          <div class="card bookoject">
            <img class="card-img-top" src="book/1.jpg" alt="Card image cap">
            <div class="card-block">
              <h4 class="card-title">Đối thoại với nhà báo</h4>
              <p class="card-text"><small class="text-muted">Tác giá : Duy Khanh</small></p>
            </div>
          </div>
          </div>
          <div class="col-sm-3">
          <div class="card bookoject">
            <img class="card-img-top" src="book/1.jpg" alt="Card image cap">
            <div class="card-block">
              <h4 class="card-title">Đối thoại với nhà báo</h4>
              <p class="card-text"><small class="text-muted">Tác giá : Duy Khanh</small></p>
            </div>
          </div>
          </div>
          <div class="col-sm-3">
          <div class="card bookoject">
            <img class="card-img-top" src="book/2.jpg" alt="Card image cap">
            <div class="card-block">
              <h4 class="card-title">Đừng hoang tưởng về biển lớn</h4>
              <p class="card-text"><small class="text-muted">Tác giá : Alan Phan</small></p>
            </div>
          </div>
          </div>
          <div class="col-sm-3">
          <div class="card bookoject">
            <img class="card-img-top" src="book/3.jpg" alt="Card image cap">
            <div class="card-block">
              <h4 class="card-title">7 thói quen bạn trẻ thanh đạt</h4>
              <p class="card-text"><small class="text-muted">Tác giá : Sean Covey</small></p>
            </div>
          </div>
          </div>
          <div class="col-sm-3">
          <div class="card bookoject">
            <img class="card-img-top" src="book/2.jpg" alt="Card image cap">
            <div class="card-block">
              <h4 class="card-title">Đừng hoang tưởng về biển lớn</h4>
              <p class="card-text"><small class="text-muted">Tác giá : Alan Phan</small></p>
            </div>
          </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
