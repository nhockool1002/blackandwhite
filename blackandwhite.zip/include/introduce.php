<div class="col-sm-10">
    <nav class="navbar navbar-default navbar-fnt navbar-backgrnd menu-primary showcase">
    <center><div class="nav-link active" href="#"><span>Giới thiệu</span></div></center>
  </nav>
  <P ALIGN=CENTER STYLE="margin-left: 0.2in; margin-bottom: 0in; line-height: 150%">
  <FONT COLOR="#000000"><SPAN LANG="vi-VN"><B>BÀI GIỚI THIỆU TRANG
  WEB BLACK AND WHITE</B></SPAN></FONT></P>
  <UL>
  	<LI><P STYLE="margin-bottom: 0in; line-height: 150%"><FONT COLOR="#000000"><SPAN LANG="vi-VN"><B>Giới
  	thiệu sơ lược </B></SPAN></FONT>
  	</P>
  </UL>
  <P STYLE="margin-left: 0.2in; margin-bottom: 0in; line-height: 150%"><FONT COLOR="#000000"><SPAN LANG="vi-VN">Thư
  viện  điện tử Black and White  được thành lập vào
  tháng 8 năm 2017 với số vốn ban đầu là 20.000.000 đồng
   chúng tôi hoạt động với 1 nhóm 2 đơn vị :</SPAN></FONT></P><br>
  <OL>
  	<LI><P STYLE="margin-bottom: 0in"><FONT COLOR="#000000"><SPAN LANG="vi-VN"><B><SPAN STYLE="background: #ffffff">UNICEF
  	Viet Nam - Quỹ Nhi Đồng Liên hợp quốc </SPAN></B></SPAN></FONT>
  	</P>
  	<LI><P STYLE="margin-bottom: 0in"><FONT COLOR="#000000"><SPAN LANG="vi-VN"><B><SPAN STYLE="background: #ffffff">Up
  	Shift Việt Nam </SPAN></B></SPAN></FONT>
  	</P>
  </OL>
  <P STYLE="margin-left: 0.2in; margin-bottom: 0in"><FONT COLOR="#000000"><SPAN LANG="vi-VN"><SPAN STYLE="background: #ffffff">- UNICEF
  Viet Nam - Quỹ Nhi Đồng Liên hợp quốc là tổ chức trên
  thế giới bảo vệ quyền trẻ em là nhà tài trợ chính </SPAN></SPAN></FONT>
  </P>
  <P STYLE="margin-left: 0.2in; margin-bottom: 0in"><FONT COLOR="#000000"><SPAN LANG="vi-VN"><SPAN STYLE="background: #ffffff">- Up
  shift Việt Nam </SPAN></SPAN></FONT><FONT COLOR="#000000"><SPAN LANG="vi-VN"><SPAN STYLE="background: #ffffff">UPSHIFT
  hay còn gọi là DỰ ÁN VƯƠN LÊN là một dự án tìm kiếm
  và ươm mầm các dự án cộng đồng của UNICEF.</SPAN></SPAN></FONT></P>
  <P STYLE="margin-left: 0.2in; margin-bottom: 0in"><FONT COLOR="#000000"><SPAN LANG="vi-VN"><SPAN STYLE="background: #ffffff">- Vì
  thư viện của chúng tôi là thư viện điện tử dành
  riêng cho sinh viên khiếm thị trên địa bàn thành phố Hồ
  Chí Minh. Với sự triển khai thực hiện của nhóm sinh
  viên khuyết tật Black and White thông qua Up shift do VYE và
  UNICEF hướng dẫn và hỗ trợ. </SPAN></SPAN></FONT>
  </P>
  <P STYLE="margin-left: 0.2in; margin-bottom: 0in"><FONT COLOR="#000000"><SPAN STYLE="background: #ffffff">
  <SPAN LANG="vi-VN">- Cụm từ “ Black and White” là ranh giới
  giữa màu đen và màu trắng đó cũng là tượng trưng cho
  thế giói của người khiếm thị và người bình thường,
  cũng là cái tăm tối của sự ngu dốt  và sự thông tuệ
  của trí thức sáng rọi. Hai thế giới khác nhau hai mảnh
  đời trái ngược nhưng nhờ tri thức kéo họ đến gần
  nhau hơn và xóa dần cái khoảng cách ấy. </SPAN></SPAN></FONT>
  </P>
  <P STYLE="margin-left: 0.2in; margin-bottom: 0in"><FONT COLOR="#000000"><SPAN LANG="vi-VN"><SPAN STYLE="background: #ffffff">- Ngoài
  ra, màu đen là màu của mực và màu trắng là màu của
  giấy hòa quyện vào nhau tạo nên những trang giấy với
  vô vàn kiến thức nhân loại mang theo niềm tin, ước mơ
  hòa nhập cộng đồng của người khiếm thị.</SPAN></SPAN></FONT></P>
  <P STYLE="margin-left: 0.2in; margin-bottom: 0in"><FONT COLOR="#000000"><SPAN LANG="vi-VN"><SPAN STYLE="background: #ffffff">- Khởi
  đầu với một văn phòng nhỏ với 5 thành viên  và trong
  tương lai sẽ phát triển hơn .</SPAN></SPAN></FONT></P>
  <P STYLE="margin-left: 0.2in; margin-bottom: 0in"><FONT COLOR="#000000"><SPAN LANG="vi-VN"><SPAN STYLE="background: #ffffff">- Bên
  cạnh đó thư viện điện tử “ Black and White” là một
  địa chỉ tìm kiếm thông tin, tra cứu tài liệu quen thuộc
  của sinh viên khiếm thị trên địa bàn thành phố Hồ
  Chí Minh  với giao diện dễ sử dụng và hoàn toàn miễn
  phí .</SPAN></SPAN></FONT></P><br>
  <UL>
  	<LI><P STYLE="margin-bottom: 0in"><FONT COLOR="#000000"><SPAN LANG="vi-VN"><B><SPAN STYLE="background: #ffffff">Lịch
  	sử hình thành </SPAN></B></SPAN></FONT><FONT COLOR="#000000"><SPAN LANG="vi-VN"><SPAN STYLE="background: #ffffff">:
  	</SPAN></SPAN></FONT>
  	</P>
  </UL>
  <P STYLE="margin-left: 0.2in; margin-bottom: 0in"><FONT COLOR="#000000"><SPAN STYLE="background: #ffffff">“
  <SPAN LANG="vi-VN">- "Black and White” là một thư viện điện
  tử  dùng để tìm kiếm, tra cứu tài liệu , tải tài lệu
  miễn phí dành riêng cho người khiếm thị trên địa bàn
  thành phố Hồ Chí Minh  độ tuổi từ 18 -25 tuổi. </SPAN></SPAN></FONT>
  </P>
  <P STYLE="margin-left: 0.2in; margin-bottom: 0in"><FONT COLOR="#000000"><SPAN LANG="vi-VN"><SPAN STYLE="background: #ffffff">- Tháng
  8 năm 2017  Black and White  được thành lập với 5 thành
  viên, trụ sở văn phòng tạm thời đặt ở Tp. Hồ Chí
  Minh, thư viện Black and white tập trung vào việc tải chỉnh
  sửa, scan tài liệu, định dạng phông phù hợp, in ấn
  tài liệu hoàn toàn miễn phí cho sinh viên khiếm thị trên
  địa bàn thành phố Hồ Chí Minh.</SPAN></SPAN></FONT></P><br>
  <UL>
  	<LI><P STYLE="margin-bottom: 0in"><FONT COLOR="#000000"><SPAN LANG="vi-VN"><B><SPAN STYLE="background: #ffffff">Tầm
  	nhìn – sứ mệnh </SPAN></B></SPAN></FONT>
  	</P>
  </UL>
  <UL>
  	<P STYLE="margin-bottom: 0in"><FONT COLOR="#000000"><SPAN LANG="vi-VN"><B><SPAN STYLE="background: #ffffff"> + Tầm
  	nhìn</SPAN></B></SPAN></FONT><FONT COLOR="#000000"><SPAN LANG="vi-VN"><SPAN STYLE="background: #ffffff">
  	:  trở thành một nơi cung cấp tài liệu miễn phí cho
  	sinh viên khiếm thị .</SPAN></SPAN></FONT></P>
  	<P STYLE="margin-bottom: 0in"><FONT COLOR="#000000"><SPAN LANG="vi-VN"><B><SPAN STYLE="background: #ffffff"> + Sứ
  	mệnh</SPAN></B></SPAN></FONT><FONT COLOR="#000000"><SPAN LANG="vi-VN"><SPAN STYLE="background: #ffffff">:
  	mang đến cho sinh viên khiếm thị tài liệu phù hợp, nơi
  	chia sẻ và tiếp nhận tài liệu, thông tin việc làm, học
  	bổng phục vụ cho nhu cầu học tập cũng như hoàn thiện
  	bản thân hòa nhập cộng đồng của người khiếm thị.</SPAN></SPAN></FONT></P>
  </UL>
  <P STYLE="margin-left: 0.2in; margin-bottom: 0in"><FONT COLOR="#000000"><SPAN LANG="vi-VN"><SPAN STYLE="background: #ffffff">- Điểm
  đặc biệt của Black and White :  địa chỉ tìm kiếm tra
  cứu tài liệu, tài liệu đa dạng , phù hợp chuyên ngành,
  định dạng file doc phù hợp, giao diện dễ sử dụng, tài
  liệu tải về hoàn toàn miễn phí.</SPAN></SPAN></FONT></P><br>
  <UL>
  	<LI><P STYLE="margin-bottom: 0in"><FONT COLOR="#000000"><SPAN LANG="vi-VN"><B><SPAN STYLE="background: #ffffff">Tôn
  	chỉ hoạt đông </SPAN></B></SPAN></FONT>
  	</P>
  </UL>
  <UL>
<P STYLE="margin-bottom: 0in"><FONT COLOR="#000000"><SPAN LANG="vi-VN"><SPAN STYLE="background: #ffffff">- Tôn
  	chỉ hoạt động của thư viện Black and White  là  đáp
  	ứng được nhu cầu tìm kiếm và tra cứu tài liệu, nắm
  	bắt được nguyện vọng của sinh viên khiếm thị  và
  	đáp ứng nguyện vọng đó một cách tốt nhất thông qua
  	tài liệu tìm kiếm được.</SPAN></SPAN></FONT></P>
  </P>
<P STYLE="margin-bottom: 0in"><FONT COLOR="#000000"><SPAN LANG="vi-VN"><SPAN STYLE="background: #ffffff">- Sự
  	gắn bó mật thiết của thư viện Black and White với VYE
  	và Unicef và các nhà tài trợ, các tổ chức xã hội là
  	tài sản vô giá và là sự hỗ trợ đắc lực, tạo nền
  	tảng cho thư viện Black and White duy trì hoạt động và
  	phát triển hơn trong tương lai.</SPAN></SPAN></FONT></P>
  </UL>
</div>
