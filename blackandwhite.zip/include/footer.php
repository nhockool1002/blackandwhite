<footer>
<div class="container">
<div class="row">
  <div class="col-md-4 col-sm-6 footerleft ">
    <div class="logofooter text=sm=center"><center><img src="img/ntt.png" width="100px"></center></div>
    <p><i class="fa fa-map-pin"></i> C918 chung cư Tân Phước P7 Q11, TPHCM</p>
    <p><i class="fa fa-phone"></i> Phone : 0985990677</p>
    <p><i class="fa fa-envelope"></i> E-mail : blackandwhitelibrary@gmail.com</p>

  </div>
  <div class="col-md-2 col-sm-6 paddingtop-bottom">
    <h6 class="heading7">Liên kết</h6>
    <ul class="footer-ul">
      <li><a href="#"> Career</a></li>
      <li><a href="#"> Privacy Policy</a></li>
      <li><a href="#"> Terms & Conditions</a></li>
      <li><a href="#"> Client Gateway</a></li>
      <li><a href="#"> Ranking</a></li>
      <li><a href="#"> Case Studies</a></li>
      <li><a href="#"> Frequently Ask Questions</a></li>
    </ul>
  </div>
  <div class="col-md-3 col-sm-6 paddingtop-bottom">
    <h6 class="heading7">Sách mới nhất</h6>
    <div class="post">
      <p>Đối thoại với nhà báo <span>Tháng 7, 2017</span></p>
      <p>Đừng hoang tưởng về biển lớn <span>Tháng 3, 2015</span></p>
      <p>7 thói quen bạn trẻ thanh đạt <span>Tháng 2, 2012</span></p>
    </div>
  </div>
  <div class="col-md-3 col-sm-6 paddingtop-bottom">
    <div class="fb-page" data-href="https://www.facebook.com/facebook" data-tabs="timeline" data-height="300" data-small-header="false" style="margin-bottom:15px;" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true">
      <div class="fb-xfbml-parse-ignore">
        <a href="#" class="fa fa-facebook"></a>
        <a href="#" class="fa fa-twitter"></a>
        <a href="#" class="fa fa-youtube"></a>
        <a href="#" class="fa fa-skype"></a>
        <a href="#" class="fa fa-rss"></a>
      </div>
    </div>
  </div>
</div>
</div>
</footer>
<!--footer start from here-->

<div class="copyright">
<div class="container">
<div class="col-md-6">
  <p>© 2017 - BlackAndWhite Project Design by Nguyễn Minh Nhựt</p>
</div>
<div class="col-md-6">
  <ul class="bottom_ul">
    <li><a href="#">webenlance.com</a></li>
    <li><a href="#">About us</a></li>
    <li><a href="#">Blog</a></li>
    <li><a href="#">Faq's</a></li>
    <li><a href="#">Contact us</a></li>
    <li><a href="#">Site Map</a></li>
  </ul>
</div>
</div>
</div>
