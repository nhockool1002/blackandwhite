<footer>
<div class="container-fluid">
  <div class="row">
    <div class="col-sm-12 text-sm-center">
        <div class="container-fluid">
          <div class="row">
            <div class="col-sm-6">
                <div class="container-fluid">
                  <div class="row">
                    <div class="col-sm-2">
                      <img src="http://thuyxuantien.com/_2/img/ntt.png" style="width:80px;">
                    </div>
                    <div class="col-sm-10 contactft">
                      <span>Address: H3 Building, 384 Hoàng Diệu, P6, Q4, TPHCM </span><br>
                      <span>Phone : 0985990677</span><br>
                      <span>E-mail : blackandwhitelibrary@gmail.com</span>
                    </div>
                  </div>
                </div>
            </div>
            <div class="col-sm-3">
                <div class="container">
                  <div class="row linka">
                    <div class="col-sm-4">
                      <a href="#"><span>Link1</span><br></a>
                      <a href="#"><span>Link2</span><br></a>
                      <a href="#"><span>Link3</span></a>
                    </div>
                    <div class="col-sm-4">
                      <a href="#"><span>Link4</span><br></a>
                      <a href="#"><span>Link5</span><br></a>
                      <a href="#"><span>Link6</span></a>
                    </div>
                    <div class="col-sm-4">
                      <a href="#"><span>Link7</span><br></a>
                      <a href="#"><span>Link8</span><br></a>
                      <a href="#"><span>Link9</span></a>
                    </div>
                  </div>
                </div>
            </div>
            <div class="col-sm-3">
                <div class="container">
                  <div class="row">
                    <div class="col-sm-12">
                      <span>Mạng xã hội</span>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-sm-12">
                      <a href="#" class="fa fa-facebook"></a>
                      <a href="#" class="fa fa-youtube"></a>
                      <a href="#" class="fa fa-twitter"></a>
                      <a href="#" class="fa fa-skype"></a>
                      <a href="#" class="fa fa-rss"></a>
                    </div>
                  </div>
                </div>
            </div>
          </div>
        </div>
    </div>
  </div>
</div>
</footer>
