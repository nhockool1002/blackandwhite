<div class="col-sm-2 menu-left">
  <ul class="nav nav-pills nav-stacked">
    <li class="nav-item">
      <div href="#" class="nav-link active category">Danh mục sách</div>
    </li>
    <li class="nav-item">
      <a href="#" class="nav-link"><span class="glyphicon glyphicon-th"></span>⏏ Tâm Lý</a>
    </li>
    <li class="nav-item">
      <a href="#" class="nav-link"><span class="glyphicon glyphicon-th"></span>⏏ Tin học</a>
    </li>
    <li class="nav-item">
      <a href="#" class="nav-link"><span class="glyphicon glyphicon-th"></span>⏏ Văn học</a>
    </li>
    <li class="nav-item">
      <a href="#" class="nav-link"><span class="glyphicon glyphicon-th"></span>⏏ Toán học</a>
    </li>
    <li class="nav-item">
      <a href="#" class="nav-link"><span class="glyphicon glyphicon-th"></span>⏏ Đời sống</a>
    </li>
  </ul>

</div>
