<div class="container-fluid">
  <div class="row">
    <div class="col-sm-12">
      <nav class="navbar navbar-default navbar-fnt navbar-backgrnd menu-primary">
        <ul class="nav navbar-nav">
          <li class="nav-item active firstitem">
            <a class="nav-link first-item" href="index.php">Trang chủ<span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item active">
            <a class="nav-link first-item" href="index.php?page=gioi-thieu">Giới thiệu<span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle item-menu-primary" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">Bảng điều khiển</a>
            <div class="dropdown-menu">
              <p class="dropdown-item"><b>Sách trong nước</b></p>
              <div class="dropdown-divider"></div>
             <a class="dropdown-item" href="index.php">Chuyên nghành</a>
             <a class="dropdown-item" href="index.php">Môn chung</a>
             <a class="dropdown-item" href="index.php">Tham khảo</a>
             <div class="dropdown-divider"></div>
             <p class="dropdown-item"><b>Sách nước ngoài</b></p>
             <div class="dropdown-divider"></div>
            <a class="dropdown-item" href="index.php">Chuyên nghành</a>
            <a class="dropdown-item" href="index.php">Môn chung</a>
            <a class="dropdown-item" href="index.php">Tham khảo</a>
             </div>
          </li>
          <li class="nav-item active">
            <a class="nav-link first-item" href="index.php?page=test">Tìm kiếm việc làm<span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item active">
            <a class="nav-link first-item" href="index.php">Kết nối bạn bè<span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item active">
            <a class="nav-link first-item" href="index.php">Gương điển hinh<span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item active">
            <a class="nav-link first-item" href="index.php">Nhà tài trợ<span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item active">
            <a class="nav-link first-item" href="index.php">Liên hệ<span class="sr-only">(current)</span></a>
          </li>
          <form class="form-inline text-sm-right searchbox">
              <input class="form-control" type="text" placeholder="Search" style="width:200px;">
          </form>
        </ul>
      </nav>
    </div></div>
</div>
