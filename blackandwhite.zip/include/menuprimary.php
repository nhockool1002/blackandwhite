<div class="container-fluid">
  <div class="row">
    <div class="col-sm-12">
      <nav class="navbar navbar-default navbar-fnt navbar-backgrnd menu-primary">
        <ul class="nav navbar-nav">
          <li class="nav-item active firstitem">
            <a class="nav-link first-item" href="index.php">Trang chủ<span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item active">
            <a class="nav-link first-item" href="index.php?page=gioi-thieu">Giới thiệu<span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item active">
            <a class="nav-link first-item" href="index.php?page=test">Tài liệu<span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item active">
            <a class="nav-link first-item" href="index.php?page=tin-tuyen-dung">Tìm kiếm việc làm<span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item active">
            <a class="nav-link first-item" href="index.php">Kết nối bạn bè<span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item active">
            <a class="nav-link first-item" href="index.php?page=tin-hoc-bong">Học bổng<span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item active">
            <a class="nav-link first-item" href="index.php">Nhà tài trợ<span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item active">
            <a class="nav-link first-item" href="index.php">Liên hệ<span class="sr-only">(current)</span></a>
          </li>
          <form class="form-inline text-sm-right searchbox">
              <input class="form-control" type="text" placeholder="Search" style="width:200px;">
          </form>
        </ul>
      </nav>
    </div></div>
</div>
