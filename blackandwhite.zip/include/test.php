<div class="col-sm-10">
    <nav class="navbar navbar-default navbar-fnt navbar-backgrnd menu-primary showcase">
    <center><div class="nav-link active" href="#"><span>Giới thiệu</span></div></center>
  </nav>
  <div class="container">
    <div class="row">
      <div class="col-sm-8">
        <object data="doc/test.pdf" type="application/pdf" width="100%" height="800px">
   <p><b>Example fallback content</b>: This browser does not support PDFs. Please download the PDF to view it: <a href="/pdf/sample-3pp.pdf">Download PDF</a>.</p>
</object>
      </div>
      <iframe src="doc/test.docx" width="70%" height="80">
 <ilayer src="doc/test.docx">
   <p>See our <a href="doc/test.docx">newsflashes</a>.</p>
 </ilayer>
</iframe>
    </div>
  </div>
</div>
