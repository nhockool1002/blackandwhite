<meta charset="utf-8">
<title><?php echo $sitename." - ".$slogan; ?></title>
<link href="https://fonts.googleapis.com/css?family=Pridi&amp;subset=latin-ext,thai,vietnamese" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Fira+Sans+Extra+Condensed:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Oswald:200,300,400,500,600,700&amp;subset=vietnamese" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Prata&amp;subset=vietnamese" rel="stylesheet">
<meta name="viewport" content="width=device-width, initial-scale=1">
<script type="text/javascript" src="vendor/bootstrap.js"></script>
<script type="text/javascript" src="js/jquery-3.2.1.min.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<link rel="stylesheet" href="vendor/bootstrap.css">
<link rel="stylesheet" href="vendor/font-awesome.css">
<link rel="stylesheet" href="style/style.css">
<link rel="icon" href="img/logo.png" type="image/x-icon"/>
<link rel="shortcut icon" href="img/logo.png" type="image/x-icon"/>
