<div class="container-fluid">
  <div class="row">
    <div class="col-sm-2 push-1-sm logo">
      <img src="img/logo.png" alt="" height="200px">
    </div>
    <div class="col-sm-10">
      <div class="row banner">
        <div class="col-sm-12">
          <img src="img/banner.png" alt="">
        </div>
      </div>
    </div>
  </div>
</div>
